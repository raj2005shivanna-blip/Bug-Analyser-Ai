---
name: Luminous Ether
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#464555'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#7e3000'
  on-tertiary: '#ffffff'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  surface-off: '#F2F2F2'
  surface-stroke: '#E5E5E5'
  accent-lime: '#C8FF44'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 120px
    fontWeight: '800'
    lineHeight: 110px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

The design system embodies a "Polished Brutalist" aesthetic—a high-end, editorial approach to SaaS that prioritizes structural clarity and ethereal depth. It targets high-growth startups and creative enterprises that value precision and avant-garde presentation.

The visual language is defined by the tension between sharp, architectural grids and soft, luminous surfaces. Drawing inspiration from GSAP-driven motion, the interface should feel "magnetic"—elements should respond to user presence with fluid, high-performance transitions. The emotional response is one of effortless sophistication, clarity, and technical mastery.

**Key Stylistic Pillars:**
- **Luminous Surfaces:** Overlapping white-on-white layers with microscopic tonal shifts.
- **Architectural Grid:** Heavy use of vertical and horizontal lines to define space, but executed with subtle, low-opacity strokes.
- **Micro-interactions:** Magnetic cursor effects on buttons and spring-based scaling on interactive cards.

## Colors

The palette is a study in "High-Key" minimalism. The foundation is built on **Warm White (#F9F9F9)** to avoid the sterile coldness of pure hex white. 

- **Primary Indigo (#4F46E5):** Reserved strictly for primary calls-to-action and active states. It should appear like a "light" in the ether.
- **Text & Contrast (#1A1A1A):** Used for typography to ensure maximum legibility and a grounding force against the light backgrounds.
- **The GSAP Lime (#C8FF44):** Brought in from the reference as a tertiary "signal" color for success states or highlights, providing a modern, technical spark.
- **Tonal Layers:** Use `#F2F2F2` for secondary containers and `#E5E5E5` for borders and dividers to maintain a soft, low-contrast UI skeleton.

## Typography

Typography is the primary visual driver. **Plus Jakarta Sans** provides a modern, geometric warmth for headlines, while **Inter** ensures utilitarian clarity for dense SaaS data.

**Statement Typography:**
- **Display XL:** Use for hero sections. Headlines should be "oversized" and tightly tracked to create a massive visual impact.
- **Mono Accents:** **JetBrains Mono** is used for small labels, tags, and "metadata" to lean into the technical GSAP inspiration.
- **Hierarchy:** Always favor extreme scale contrast. If a headline is large, keep the surrounding body text significantly smaller and well-spaced.

## Layout & Spacing

The layout follows a **Strict 12-Column Grid** with a brutalist influence. Sections are clearly defined by 1px strokes in `#E5E5E5`.

- **Generous Whitespace:** Padding between major sections should be at least 160px on desktop to allow the "ether" to breathe.
- **Asymmetric Balance:** Align content to the grid, but use "broken" layouts where text spans 5 columns and imagery spans 7 to create visual interest.
- **Magnetic Margins:** Interactive elements (buttons, cards) should have a wide hit-area that triggers a magnetic pull animation before the actual click.
- **Mobile Reflow:** On mobile, the 12-column grid collapses to a 4-column stack. Typography scales aggressively to maintain the "oversized" feel without breaking the viewport.

## Elevation & Depth

Depth is conveyed through **Tonal Stacking** and **Soft Shadows**, rather than heavy gradients.

- **The "Luminous" Shadow:** Use large, highly diffused shadows with very low opacity (e.g., `0 20px 40px rgba(0,0,0,0.04)`). The shadow should feel like a soft ambient occlusion rather than a direct light source.
- **Layering:** High-priority cards sit on `#FFFFFF`. Secondary containers sit on `#F2F2F2`. 
- **Backdrop Blur:** Use subtle `10px` blurs for navigation bars and dropdowns to maintain the "frosted glass" ether effect, ensuring content behind is still hinted at.

## Shapes

The shape language is **"Soft-Brutalist."** 

While traditional brutalism uses sharp 90-degree angles, this design system uses a standard `4px` (0.25rem) radius for most UI components (inputs, cards, small buttons). This provides just enough softening to feel "premium" while maintaining an architectural, rigid structure. 

Large-scale components like hero sections or main navigation containers may use `rounded-lg` (8px) to emphasize their presence as floating islands in the ether.

## Components

### Buttons
- **Primary:** Solid Indigo (#4F46E5) with white text. High-performance magnetic hover effect (GSAP).
- **Secondary:** Transparent with a 1px border (#E5E5E5). Fills with #1A1A1A on hover.
- **Size:** Large padding (16px 32px) to match the oversized typography.

### Input Fields
- **Styling:** Minimalist bottom-border only or very light 1px stroke. 
- **Focus State:** Border transitions to Indigo with a subtle outer glow. Label floats up using the Mono font.

### Cards
- **Structure:** No border. White fill (#FFFFFF). 
- **Interaction:** On hover, the card should scale slightly (1.02x) and the "Luminous" shadow should deepen.

### Chips & Tags
- **Styling:** Using `label-mono` typography. Backgrounds use the `#C8FF44` accent for "Active" or "New" status, otherwise #E5E5E5.

### Navigation
- **Floating Header:** A pill-shaped or full-width bar with a `backdrop-filter: blur(12px)`.
- **Links:** Upper-case, JetBrains Mono, with a persistent underscore that expands on hover.